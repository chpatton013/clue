/****************/
/ IMPORTANT!!    /
/****************/

By opening and playing the game Indication, you are agreeing to the 
acceptance and understanding that you may be playing a partially completed
game. 

How To Start Indication:

IMPORTANT: In order to run the client, you must have at least one server up and
avaliable. This is our DRM system that has been put in place to prevent piracy
of the game Indication from those who would be. We apologize for the inconvience.

For Mac OS X:

1. Open your terminal

2. Navigate to the location of the folder that you have downloaded

3. If you do not already have a server on your network, you may:
 - Start the Server with the command: java -jar IndicationServer.jar
 - Wait for someone else on your local network to start a server
If there is already a server avaliable to you, you may proceed to step 5.

4. If you had to start a server, open a new terminal, then proceed back to the
location you downloaded the folder

5. Start the Client with the command: java -jar IndicationClient.jar

For Windows:

1. Navigate to the location of the folder that you have downloaded

2. If you do not already have a server on your network, you may:
 - Start the Server by double-clicking on IndicationServer.bat
 - Wait for someone else on your local network to start a server
If there is already a server avaliable to you, you may proceed to step 3.

3. Start the Client by double-clicking on IndicationClient.bat

Exiting the game:

1. Be sure that the client navigates back to the main menu screen 
(The screen will have Indication in the center and 4 options)

2. Click on the Red button on the upper-right (a circle for Mac, and X for windows)
to exit the game.

3. To End the Server:
 (On Mac OS X) on the terminal you started the server, press CTRL + C to end it.
 (On Windows) find the appropriate command prompt and exit it
	